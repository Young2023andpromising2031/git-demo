//头部轮播图
	var picture = document.getElementById("picture");
	var seeding = document.getElementsByClassName("seeding")[1]
	var imgArr = document.getElementsByTagName("img");

	// picture.style.width = 1690 * imgArr.length + "px";

	var navDiv = document.getElementById("navDiv");
	var index = 0;
	//获取所有的button
	var allButton = document.getElementsByClassName("button");
	allButton[index].style.backgroundColor = "blue";

	for (var i = 0; i < allButton.length; i++) {
		//为每一个超链接添加num属性
		allButton[i].num = i;
		allButton[i].onclick = function() {
			index = this.num;
			setButton();
			seeding.style.left = -1690 * index + "px";
			move(seeding, "left", -1690 * index, 5, function() {});
		};
	}
	// setButton();
	//move函数

	//设置选中的a图标
	function setButton() {
		for (var i = 0; i < allButton.length; i++) {
			if (index == i) {
				allButton[i].style.backgroundColor = "blue";
			} else {
				allButton[i].style.backgroundColor = "white";
			}

		}
	};
	//创建一个函数用来开启自动切换图片
	function autoChange() {
		// 	//开启定时器，定时切换图片
		setInterval(function() {
			index++;
			// move(seeding, "left", -1690 * index, 1, function() {})
		}, 1000)
	}
	// 自动切换图片
	autoChange();
	//尾部轮播图
	var EndPicture = document.getElementsByClassName("EndPicture");
	var imgArr = document.getElementsByTagName("img");
